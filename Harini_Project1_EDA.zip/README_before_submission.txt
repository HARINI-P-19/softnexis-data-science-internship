Titanic Dataset: Exploratory Data Analysis and Visualization

The Titanic dataset was analysed using Pandas, NumPy, Matplotlib, and Seaborn. The dataset contains passenger information, including age, gender, passenger class, fare, family relationships, and survival status. Data cleaning was performed by filling missing age values with the median, replacing missing embarkation values with the mode, and removing the Cabin column because it contained a large proportion of missing values. Duplicate records were also checked and removed.

Three important findings emerged from the exploratory analysis.

First, survival rates differed significantly by gender.** Female passengers had a substantially higher survival rate than male passengers. This indicates that gender was strongly associated with survival outcomes in the dataset.

Second, passenger class was associated with survival.** Passengers travelling in first class generally had a higher survival rate than those in second and third class. The correlation heatmap also helps demonstrate the negative relationship between passenger class number and survival, because a higher class number represents a lower passenger class.

Third, passenger fares showed a positive relationship with survival.** The correlation analysis indicates that passengers who paid higher fares tended to have better survival outcomes. The fare boxplot and age-versus-fare scatter plot provide additional ways to examine differences between passenger groups.

Six visualizations were created: a survival-rate bar chart, an age-distribution histogram, a passenger-class pie chart, a fare boxplot, a correlation heatmap, and an age-versus-fare scatter plot. A dashboard combining four charts was also generated.

Overall, this project demonstrates how data cleaning, exploratory analysis, and visualization can reveal meaningful patterns in a dataset before applying machine-learning models.