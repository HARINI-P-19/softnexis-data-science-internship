Soft Nexis Technology — Project 3: NLP & Sentiment Analysis

Included:
- Harini_Project3_NLP.ipynb (uploaded executed notebook, renamed as required)
- top_words_by_sentiment.png
- tfidf_matrix_evidence.png
- sentiment_confusion_matrix.png
- wordcloud_positive.png
- wordcloud_negative.png
- feature_importance_nlp.png
- nlp_model_comparison.png
- TFIDF_and_Sentiment_Report.txt

Important: The uploaded notebook's outputs show that sentiment_model.pkl was saved in the original Colab runtime, but the actual .pkl binary was not attached with the uploaded notebook. Download sentiment_model.pkl from that Colab runtime and add it to this folder before submitting. If the runtime has expired, rerun the final notebook cell to regenerate it.

The TF-IDF evidence PNG is a clean evidence panel based on the saved notebook output, not a literal screenshot of the Colab interface.